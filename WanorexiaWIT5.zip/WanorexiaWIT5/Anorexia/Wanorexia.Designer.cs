﻿namespace Anorexia
{
    partial class LAnorexia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnYes = new System.Windows.Forms.Button();
            this.btnNo = new System.Windows.Forms.Button();
            this.lblNNDumpTo = new System.Windows.Forms.Label();
            this.lblDirectory = new System.Windows.Forms.Label();
            this.pbar = new System.Windows.Forms.ProgressBar();
            this.lblBarAction = new System.Windows.Forms.Label();
            this.cbDelete = new System.Windows.Forms.CheckBox();
            this.cbCopy = new System.Windows.Forms.CheckBox();
            this.lblErToss = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BtnYes
            // 
            this.BtnYes.BackColor = System.Drawing.Color.Lime;
            this.BtnYes.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnYes.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnYes.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.BtnYes.Location = new System.Drawing.Point(31, 112);
            this.BtnYes.Name = "BtnYes";
            this.BtnYes.Size = new System.Drawing.Size(95, 39);
            this.BtnYes.TabIndex = 0;
            this.BtnYes.Text = "PURGE!";
            this.BtnYes.UseVisualStyleBackColor = false;
            this.BtnYes.Click += new System.EventHandler(this.BtnYes_Click);
            // 
            // btnNo
            // 
            this.btnNo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNo.Location = new System.Drawing.Point(570, 112);
            this.btnNo.Name = "btnNo";
            this.btnNo.Size = new System.Drawing.Size(95, 39);
            this.btnNo.TabIndex = 1;
            this.btnNo.Text = "Or Not";
            this.btnNo.UseVisualStyleBackColor = false;
            this.btnNo.Click += new System.EventHandler(this.btnNo_Click);
            // 
            // lblNNDumpTo
            // 
            this.lblNNDumpTo.AutoSize = true;
            this.lblNNDumpTo.Location = new System.Drawing.Point(28, 33);
            this.lblNNDumpTo.Name = "lblNNDumpTo";
            this.lblNNDumpTo.Size = new System.Drawing.Size(360, 17);
            this.lblNNDumpTo.TabIndex = 3;
            this.lblNNDumpTo.Text = "Place all files in all directories to \'Purged\' from directory:";
            // 
            // lblDirectory
            // 
            this.lblDirectory.AutoSize = true;
            this.lblDirectory.Location = new System.Drawing.Point(28, 70);
            this.lblDirectory.Name = "lblDirectory";
            this.lblDirectory.Size = new System.Drawing.Size(0, 17);
            this.lblDirectory.TabIndex = 4;
            // 
            // pbar
            // 
            this.pbar.ForeColor = System.Drawing.Color.Black;
            this.pbar.Location = new System.Drawing.Point(31, 203);
            this.pbar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbar.Name = "pbar";
            this.pbar.Size = new System.Drawing.Size(634, 29);
            this.pbar.Step = 1;
            this.pbar.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.pbar.TabIndex = 5;
            // 
            // lblBarAction
            // 
            this.lblBarAction.AutoSize = true;
            this.lblBarAction.Location = new System.Drawing.Point(31, 169);
            this.lblBarAction.Name = "lblBarAction";
            this.lblBarAction.Size = new System.Drawing.Size(0, 17);
            this.lblBarAction.TabIndex = 6;
            // 
            // cbDelete
            // 
            this.cbDelete.AutoSize = true;
            this.cbDelete.Checked = true;
            this.cbDelete.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbDelete.Location = new System.Drawing.Point(32, 298);
            this.cbDelete.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbDelete.Name = "cbDelete";
            this.cbDelete.Size = new System.Drawing.Size(194, 21);
            this.cbDelete.TabIndex = 7;
            this.cbDelete.Text = "Move files to target Folder";
            this.cbDelete.UseVisualStyleBackColor = true;
            this.cbDelete.CheckedChanged += new System.EventHandler(this.cbDelete_CheckedChanged);
            // 
            // cbCopy
            // 
            this.cbCopy.AutoSize = true;
            this.cbCopy.Location = new System.Drawing.Point(31, 336);
            this.cbCopy.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbCopy.Name = "cbCopy";
            this.cbCopy.Size = new System.Drawing.Size(188, 21);
            this.cbCopy.TabIndex = 8;
            this.cbCopy.Text = "Copy files to target folder";
            this.cbCopy.UseVisualStyleBackColor = true;
            this.cbCopy.CheckedChanged += new System.EventHandler(this.cbCopy_CheckedChanged);
            // 
            // lblErToss
            // 
            this.lblErToss.AutoSize = true;
            this.lblErToss.Location = new System.Drawing.Point(34, 250);
            this.lblErToss.Name = "lblErToss";
            this.lblErToss.Size = new System.Drawing.Size(12, 17);
            this.lblErToss.TabIndex = 9;
            this.lblErToss.Text = " ";
            // 
            // LAnorexia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(693, 422);
            this.Controls.Add(this.lblErToss);
            this.Controls.Add(this.cbCopy);
            this.Controls.Add(this.cbDelete);
            this.Controls.Add(this.lblBarAction);
            this.Controls.Add(this.pbar);
            this.Controls.Add(this.lblDirectory);
            this.Controls.Add(this.lblNNDumpTo);
            this.Controls.Add(this.btnNo);
            this.Controls.Add(this.BtnYes);
            this.Name = "LAnorexia";
            this.Text = "Wanorexia";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnYes;
        private System.Windows.Forms.Button btnNo;
        private System.Windows.Forms.Label lblNNDumpTo;
        private System.Windows.Forms.Label lblDirectory;
        private System.Windows.Forms.ProgressBar pbar;
        private System.Windows.Forms.Label lblBarAction;
        private System.Windows.Forms.CheckBox cbDelete;
        private System.Windows.Forms.CheckBox cbCopy;
        private System.Windows.Forms.Label lblErToss;
    }
}

